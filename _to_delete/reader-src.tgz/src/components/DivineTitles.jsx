import { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { apiDivineTitles, apiDivineTitleRefs, apiBookOrder, apiTokens, apiDocTokens, apiTransChapter } from '../lib/api.js';
import { parallelHref } from '../lib/bookSlug.js';
import WordBlock from './WordBlock.jsx';
import './DivineTitles.css';
import NovelText from './NovelText.jsx';

// Divine Titles tab (/lexicon-page?tab=divine) — every name and honorific title
// of Yah, with every verse it occurs in across the whole corpus: BHS for the OT,
// the HEB edition for the NT / Apocrypha / Josephus, and the Works Library docs.
// Everything is baked into surface-index.db (server/build-divine-titles.js); this
// page only reads it. Transliterations come from the server (strongs-roots.json
// + the hyphen allowlist) — never spelled here.
//
// fieldy, 2026-09-24: stay on this page — pick a written variant ("only Yahaw"),
// click a chapter:verse and the verse loads right here with that word
// highlighted, with a link out to the verse if wanted. Books the main reader
// shows come first (in its own order); every other work sits behind "More works".

const GROUPS = [
  { key: 'name',     label: 'The Name' },
  { key: 'title',    label: 'Titles' },
  { key: 'compound', label: 'Compound titles' },
  { key: 'other',    label: 'Other gods — the same words, not gold' },
];
const SRC_LABEL = { BHS: 'Hebrew (BHS)', HEB: 'Hebrew extra', DOC: 'Works Library' };
const fmt = n => Number(n || 0).toLocaleString();

function verseHref(book, c, v) {
  if (book.src === 'DOC') return `/?source=HEB&doc=${encodeURIComponent(book.code)}&chapter=${c}&verse=${v}`;
  return parallelHref(book.book_id, null, c, v, book.src === 'HEB' ? 'HEB' : null);
}

// One fetch per chapter for the life of the page — opening several verses of
// the same chapter (Psalm 150:1 … 150:6) costs a single request.
const _chapterCache = new Map();
function loadChapter(book, c) {
  const key = `${book.src}|${book.book_id ?? book.code}|${c}`;
  if (!_chapterCache.has(key)) {
    const words = book.src === 'DOC'
      ? apiDocTokens(book.code, c)
      : apiTokens(book.book_id, c, book.src === 'HEB' ? 'HEB' : undefined);
    const english = book.src === 'DOC' ? Promise.resolve({ verses: [] }) : apiTransChapter(book.book_id, c).catch(() => ({ verses: [] }));
    _chapterCache.set(key, Promise.all([words, english]).catch(e => { _chapterCache.delete(key); throw e; }));
  }
  return _chapterCache.get(key);
}

// Is this word one of the focus words? The server stamps each title word with
// comp.divineForms = {title id: form} (baked, build-divine-titles.js), so the
// match is exact: this title, and one of the forms in view. No respelling, no
// guessing across prefix-merged words (AthaHallayawan = 𐤀𐤕 + 𐤄𐤏𐤋𐤉𐤅𐤍) — and the
// preposition 𐤀𐤋 "to" can never light up next to Al.
function isFocus(w, forms, titleId) {
  if (!forms.size) return false;
  return (w.components || []).some(c => c && c.divineForms && forms.has(c.divineForms[titleId]));
}

function VersePanel({ book, c, v, focusForms, titleId, onClose }) {
  const [data, setData] = useState(null);
  const [err, setErr] = useState(null);
  const ref = useRef(null);
  // Bring the newly opened verse into view (the previous one just collapsed).
  useEffect(() => { if (data) ref.current?.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }, [data]);
  useEffect(() => {
    let off = false;
    setData(null); setErr(null);
    loadChapter(book, c)
      .then(([words, eng]) => { if (!off) setData({ words: (Array.isArray(words) ? words : []).filter(w => w.verse === v), english: (eng.verses || []).find(x => x.verse === v)?.text || '' }); })
      .catch(e => { if (!off) setErr(e.message); });
    return () => { off = true; };
  }, [book, c, v]);
  return (
    <div className="dt-verse" ref={ref}>
      <div className="dt-verse-h">
        <span className="dt-verse-ref">{book.name} {c}:{v}</span>
        <Link className="dt-verse-go" to={verseHref(book, c, v)}>Open verse →</Link>
        <button className="dt-verse-x" onClick={onClose} aria-label="Close verse">✕</button>
      </div>
      {err && <div className="dt-msg">⚠ {err}</div>}
      {!data && !err && <div className="dt-msg"><span className="spin">◌</span> Loading verse…</div>}
      {data && (
        <>
          {data.english && <NovelText as="p" className="dt-verse-en" text={data.english} />}
          <div className="dt-verse-words" dir="rtl">
            {data.words.map((w, i) => (
              <WordBlock key={i} wordObj={w} showSub showCopyBtn={false} showStrongs
                         className={isFocus(w, focusForms, titleId) ? 'dt-focus' : ''} />
            ))}
            {!data.words.length && <div className="dt-msg">No Hebrew tokens for this verse.</div>}
          </div>
        </>
      )}
    </div>
  );
}

// ONE verse open on the whole page (fieldy: "expanding another means minimizing
// where you just were") — the open verse lives in DivineTitles as
// { bookKey: "title|src|book", ref: [c, v, formsAtRef] }; opening another replaces it.
function BookRefs({ book, openAll, form, titleId, openVerse, setOpenVerse }) {
  const [open, setOpen] = useState(false);
  useEffect(() => { setOpen(openAll); }, [openAll]);
  const bookKey = `${titleId}|${book.src}|${book.book_id ?? book.code}`;
  const active = openVerse && openVerse.bookKey === bookKey ? openVerse.ref : null;
  const setActive = ref => setOpenVerse(ref ? { bookKey, ref } : null);
  // A verse opened from outside (picking a form opens its first verse) opens its book.
  useEffect(() => { if (active) setOpen(true); }, [active]);
  const n = book.refs.reduce((a, r) => a + (form ? (r[3]?.[form] || 0) : r[2]), 0);
  // Which forms to highlight: the chosen one, else every form at that verse.
  const focusForms = useMemo(() => {
    if (!active) return new Set();
    return new Set(form ? [form] : Object.keys(active[2] || {}));
  }, [active, form]);
  return (
    <div className="dt-book">
      <button className="dt-book-h" onClick={() => setOpen(o => !o)} aria-expanded={open}>
        <span className="dt-chev">{open ? '▾' : '▸'}</span>
        <span className="dt-book-name">{book.name}</span>
        {book.src !== 'BHS' && <span className="dt-src">{SRC_LABEL[book.src]}</span>}
        <span className="dt-book-n">{fmt(n)}</span>
      </button>
      {open && (
        <div className="dt-refs">
          {book.refs.map(([c, v, k, forms]) => {
            const on = active && active[0] === c && active[1] === v;
            return (
              <button key={`${c}:${v}`} className={`dt-ref ${on ? 'on' : ''}`}
                      onClick={() => setActive(on ? null : [c, v, forms])}>
                {c}:{v}{k > 1 && !form && <sup>×{k}</sup>}
              </button>
            );
          })}
        </div>
      )}
      {open && active && (
        <VersePanel book={book} c={active[0]} v={active[1]} focusForms={focusForms} titleId={titleId}
                    onClose={() => setActive(null)} />
      )}
    </div>
  );
}

function TitleCard({ t, readerOrder, openVerse, setOpenVerse }) {
  const [open, setOpen] = useState(false);
  const [refs, setRefs] = useState(null);
  const [err, setErr] = useState(null);
  const [openAll, setOpenAll] = useState(false);
  const [form, setForm] = useState(null);         // one written variant, or null = all
  const [showMore, setShowMore] = useState(false);
  useEffect(() => {
    if (!open || refs) return;
    apiDivineTitleRefs(t.id).then(d => setRefs(d.books || [])).catch(e => setErr(e.message));
  }, [open, refs, t.id]);

  // Filter to the chosen variant, then split: books the main reader shows (in
  // its order) vs every other work.
  const { main, more } = useMemo(() => {
    const main = [], more = [];
    for (const b of refs || []) {
      const rs = form ? b.refs.filter(r => r[3] && r[3][form]) : b.refs;
      if (!rs.length) continue;
      const bb = { ...b, refs: rs };
      if (b.src !== 'DOC' && readerOrder.has(b.book_id)) main.push(bb); else more.push(bb);
    }
    main.sort((a, b) => readerOrder.get(a.book_id) - readerOrder.get(b.book_id));
    return { main, more };
  }, [refs, form, readerOrder]);
  const moreCount = more.reduce((a, b) => a + b.refs.length, 0);
  // Picking a form starts fresh, as if it were the first click on the page:
  // every book collapses (BookRefs are keyed by form) and the form's FIRST
  // verse opens — never the verse left open from another form.
  const pickForm = f => {
    setForm(f);
    setOpenAll(false);
    // Same order the lists show: reader books (in reader order), then more works.
    const inReader = b => b.src !== 'DOC' && readerOrder.has(b.book_id);
    const ordered = [
      ...(refs || []).filter(inReader).sort((a, b) => readerOrder.get(a.book_id) - readerOrder.get(b.book_id)),
      ...(refs || []).filter(b => !inReader(b)),
    ];
    let first = null, firstInMore = false;
    for (const b of ordered) {
      const r = (f ? b.refs.filter(r => r[3] && r[3][f]) : b.refs)[0];
      if (r) { first = { bookKey: `${t.id}|${b.src}|${b.book_id ?? b.code}`, ref: [r[0], r[1], r[3]] }; firstInMore = !inReader(b); break; }
    }
    setShowMore(firstInMore);
    setOpenVerse(first);
  };
  const bookProps = { form, titleId: t.id, openVerse, setOpenVerse };
  const isOther = t.kind === 'other';
  const multiBook = main.length + (showMore ? more.length : 0) > 1;

  return (
    <section className={`dt-card ${isOther ? 'dt-card-other' : ''} ${t.occurrences ? '' : 'dt-card-empty'}`}>
      <button className="dt-card-h" onClick={() => setOpen(o => !o)} aria-expanded={open} disabled={!t.occurrences}>
        <span className="dt-chev">{t.occurrences ? (open ? '▾' : '▸') : '·'}</span>
        {t.paleo && <span className="dt-paleo" dir="rtl">{t.paleo}</span>}
        <span className="dt-label">{t.label}</span>
        {t.en && <span className="dt-en">({t.en})</span>}
        <span className="dt-count">
          {fmt(t.occurrences)} <small>in {fmt(t.verses)} verse{t.verses === 1 ? '' : 's'} · {fmt(t.bookCount)} book{t.bookCount === 1 ? '' : 's'}</small>
        </span>
      </button>
      {open && (
        <div className="dt-body">
          <div className="dt-meta">
            {!isOther && t.sns && <span className="dt-sns">{t.sns.join(' + ')}</span>}
            {t.forms && t.forms.length > 1 && (
              <button className={`dt-form ${form ? '' : 'on'}`} onClick={() => pickForm(null)}>All forms</button>
            )}
            {(t.forms || []).map(f => (
              <button key={f.paleo} className={`dt-form ${form === f.paleo ? 'on' : ''}`}
                      title={`${fmt(f.n)}× — show only these`}
                      onClick={() => pickForm(form === f.paleo ? null : f.paleo)}>
                <span className="dt-form-paleo" dir="rtl">{f.paleo}</span>
                <span className="dt-form-tr">{f.translit}</span>
                <span className="dt-form-n">{fmt(f.n)}</span>
              </button>
            ))}
          </div>
          {err && <div className="dt-msg">⚠ {err}</div>}
          {!refs && !err && <div className="dt-msg"><span className="spin">◌</span> Loading references…</div>}
          {refs && (
            <>
              {multiBook && (
                <button className="dt-openall" onClick={() => setOpenAll(o => !o)}>
                  {openAll ? 'Collapse all books' : 'Expand all books'}
                </button>
              )}
              {main.map(b => <BookRefs key={`${form}|${b.src}:${b.book_id}`} book={b} {...bookProps}
                                       openAll={openAll || (main.length === 1 && !more.length)} />)}
              {!main.length && !more.length && <div className="dt-msg">No verses for this form.</div>}
              {more.length > 0 && (
                <div className="dt-more">
                  <button className="dt-more-h" onClick={() => setShowMore(s => !s)} aria-expanded={showMore}>
                    <span className="dt-chev">{showMore ? '▾' : '▸'}</span>
                    More works <small>{fmt(more.length)} work{more.length === 1 ? '' : 's'} · {fmt(moreCount)} verse{moreCount === 1 ? '' : 's'}</small>
                  </button>
                  {showMore && more.map(b => <BookRefs key={`${form}|${b.src}:${b.book_id ?? b.code}`} book={b} {...bookProps}
                                                        openAll={openAll || (!main.length && more.length === 1)} />)}
                </div>
              )}
            </>
          )}
        </div>
      )}
    </section>
  );
}

export default function DivineTitles({ query = '' }) {
  const [data, setData] = useState(null);
  const [err, setErr] = useState(null);
  const [readerOrder, setReaderOrder] = useState(new Map());   // canon id -> position in the main reader
  const [openVerse, setOpenVerse] = useState(null);             // the one verse open on the page
  useEffect(() => {
    let off = false;
    apiDivineTitles().then(d => { if (!off) setData(d); }).catch(e => { if (!off) setErr(e.message); });
    apiBookOrder().then(list => { if (!off) setReaderOrder(new Map((list || []).map((b, i) => [b.id, i]))); }).catch(() => {});
    return () => { off = true; };
  }, []);

  const groups = useMemo(() => {
    if (!data) return [];
    const q = query.trim().toLowerCase();
    const all = [...(data.titles || []), ...(data.other ? [data.other] : [])];
    const hit = t => !q || [t.label, t.en, t.paleo, ...(t.sns || [])].some(x => String(x || '').toLowerCase().includes(q));
    return GROUPS.map(g => ({
      ...g,
      items: all.filter(t => (t.group || 'title') === g.key && hit(t))
        .sort((a, b) => g.key === 'compound' ? b.occurrences - a.occurrences : 0),
    })).filter(g => g.items.length);
  }, [data, query]);

  if (err) return <div className="lex-state-msg">⚠ Failed to load<br /><small style={{ color: 'var(--red)' }}>{err}</small></div>;
  if (!data) return <div className="lex-state-msg"><span className="spin">◌</span> Loading titles…</div>;
  return (
    <div className="dt-wrap">
      <p className="dt-intro">
        Every name and honorific title of Yah, across the whole corpus — the words shown
        in <span className="dt-gold">gold</span> in the word-by-word chips. Open a title, pick a
        written form to narrow it, and tap a verse to read it here.
      </p>
      {groups.map(g => (
        <div key={g.key} className="dt-group">
          <h2 className="dt-group-h">{g.label}</h2>
          {g.items.map(t => <TitleCard key={t.id} t={t} readerOrder={readerOrder} openVerse={openVerse} setOpenVerse={setOpenVerse} />)}
        </div>
      ))}
      {!groups.length && <div className="lex-state-msg">No titles match “{query}”.</div>}
    </div>
  );
}
