import { Link } from 'react-router-dom';
import { usePageTitle, pageTitle } from '../hooks/usePageTitle.js';
import './Guide.css';

/**
 * Guide — what the app does and where to find it. Replaces the Token
 * Cheatsheet as the page the landing points at: the cheatsheet is the
 * grammar of the raw BHS tokens (still at /cheatsheet for the curious);
 * this is the tour of the features a reader actually uses.
 *
 * Route: /guide
 */
const SECTIONS = [
  {
    id: 'read',
    ico: '📜',
    title: 'Read the scriptures in their own names',
    body: 'The Novel English Bible reads as clean English, but every person and place keeps its Hebrew name — Yahawadah, not Judah; Yarawashalam, not Jerusalem. The name is followed by its meaning in parentheses the first time it matters, so "Bayath-Lacham (house of bread)" tells you what the writer heard. The empty gold marker after the Name — Yahawah () — is deliberate: the Name is never glossed.',
    links: [
      { to: '/bible?book=1&chapter=1', label: 'Novel English Bible — BaRaashayath 1' },
      { to: '/bible?book=6&chapter=15&verse=11', label: 'Yahawashawai (Joshua) 15:11 — Jabneel' },
    ],
  },
  {
    id: 'hebrew',
    ico: '𐤀',
    title: 'The Hebrew itself, in paleo letters',
    body: 'The Hebrew reader shows the text in the paleo-Hebrew script the prophets wrote in — the same 22 letters, never the later square script. Tap any word for its parts: the root, the prefixes and suffixes, person, gender and number, and the Strong’s number that links it to every other place it occurs. The Greek, Latin and Ge’ez sources are one switch away inside the same reader.',
    links: [
      { to: '/?book=1&chapter=1', label: 'Hebrew reader — BaRaashayath 1:1' },
      { to: '/?source=LXX&book=1&chapter=1&verse=1', label: 'Greek (Septuagint + NT)' },
    ],
  },
  {
    id: 'parallel',
    ico: '📖',
    title: 'English and Hebrew side by side',
    body: 'The Parallel view sets the English against the Hebrew verse by verse, word-linked: hover or tap an English word and its Hebrew lights up, and the other way round. It is the fastest way to check what a translation did with a word.',
    links: [{ to: '/parallel/1/1', label: 'Parallel — BaRaashayath 1' }],
  },
  {
    id: 'maps',
    ico: '🗺',
    title: 'Interactive Story Models & Maps',
    body: 'The Holy Land in 3D is drawn from the text, not traced from an atlas: the tribal allotments of Yahawashawai (Joshua) 13–19, the millennial bands of Yachazaqaal (Ezekiel) 47–48 with the Holy Portion measured in cubits, the cities with their verses, and the rivers and seas under the names the Bible gives them. Tap any portion, city or water for its verses; every border and measurement says which verse it comes from. The Tzalam (Likeness) of the Dream is Daniel 2 in 3D: tap the dahab (gold), kasap (silver), nachash (brass), parazal (iron) and chasap (clay) for their verses, then play the aban (stone) gazar (cut) out laa (without) yadayan (hands) striking the tzalam (likeness) to pieces. The Bayath (House) of Yahawah is 1 Kings 6–7 in 3D, every measure in amah (cubits) from the text: watch the bayath (house) rise in the order the chapters give it, walk in from the gate of the gadawal (great) chatzar (court) to the arawan (ark) beneath the karawab (cherubim), or roam it on your own feet. The Bayath (House) Yachazaqaal (Ezekiel) Saw is Ezekiel 40–43 in 3D, measured in the long amah (cubit) of the man\'s qanah (reed): walk it gate by gate the way he was led — the chawamah (wall) five hundred square, the shairayam (gates), the chatzarawath (courts), the mazabach (altar), the hayakal (temple) and the most qadash (holy) place — or roam it on your own feet. The Mashakan (Tabernacle) and Its Machanah (Camp) is Exodus 25–27 and 40 in 3D with Numbers 2 about it: watch Mashah (Moses) raise it part by part in the text\'s own order — the qarashayam (boards), the yarayaihath (curtains) and the ahal (tent), the arawan (ark) behind the parakath (veil), the shalachan (table), the manawarah (lampstand), the altars and the basin, the chatzar (court) — then the inan (cloud), and the twelve camped about it by their dagal (standards); or roam it and the camp on your own feet.',
    links: [
      { to: '/models/holy-land', label: 'The Holy Land in 3D' },
      { to: '/models/holy-land?overlay=joshua', label: 'Joshua’s allotments' },
      { to: '/models/statue', label: 'The Tzalam (Likeness) of the Dream (Daniel 2)' },
      { to: '/models/temple', label: 'The Bayath (House) of Yahawah (1 Kings 6–7)' },
      { to: '/models/ezekiel', label: 'The Bayath (House) Yachazaqaal (Ezekiel) Saw (Ezekiel 40–43)' },
      { to: '/models/tabernacle', label: 'The Mashakan (Tabernacle) and Its Machanah (Camp) (Exodus 25–27, 40 · Numbers 2)' },
      { to: '/models/ezekiel-city', label: 'The Iyar (City) Yachazaqaal (Ezekiel) Saw and the Holy Portion (Ezekiel 45 · 47 · 48)' },
      { to: '/models/revelation-city', label: 'The Shairay (City) Coming Down Out of Shamayam (Heaven) (Revelation 21–22)' },
      { to: '/models/prints', label: 'Printable map sheets (PNG · SVG · PDF)' },
      { to: '/models', label: 'All story models' },
      { to: '/maps', label: 'All maps' },
    ],
  },
  {
    id: 'passages',
    ico: '📜',
    title: 'Passages',
    body: 'The named passages — the Prayer of Azarias, the Proclamation of Mardocheus, Yaiqab’s blessing on his sons, the Song of the Sea, the Ten Commandments — each on its own page with just its verses, in the same words and names as the Novel English Bible, at an address you can keep. Any reference can be opened the same way: /passage?ref=Isaiah 53.',
    links: [
      { to: '/passages', label: 'All passages' },
      { to: '/passage/jacobs-blessings', label: 'Yaiqab’s blessing on his twelve sons' },
      { to: '/passage/proclamation-of-mordecai', label: 'The Proclamation of Mardocheus' },
    ],
  },
  {
    id: 'precepts',
    ico: '⁂',
    title: 'Precepts',
    body: 'Precept upon precept, line upon line. Wherever one passage quotes another — the Psalms in Hebrews, Genesis in Jubilees, Kings in Chronicles and Josephus — a ⁂ stands in the margin beside the verse; tap it for the passages that share its words, in their own reading text, and go straight to them. The Precepts page lists them all, book by book, strongest first.',
    links: [
      { to: '/precepts', label: 'All precepts' },
      { to: '/bible?book=58&chapter=1', label: 'Hebrews 1 — the Psalms quoted' },
      { to: '/bible?book=68&chapter=15', label: 'Jubilees 15 — Genesis 17 retold' },
    ],
  },
  {
    id: 'lexicon',
    ico: '🔎',
    title: 'Lexicon, roots and concordance',
    body: 'Every word in the text is in the Lexicon: its paleo letters, transliteration, meaning, and the parts a name is built from. The Root Explorer walks a root through all its surface forms, and the Concordance lists every verse a word stands in. Search reaches across all of it — Hebrew, English, the names and the works.',
    links: [
      { to: '/lexicon-page', label: 'Lexicon' },
      { to: '/roots', label: 'Root Explorer' },
      { to: '/concordance', label: 'Concordance' },
      { to: '/search', label: 'Search' },
    ],
  },
  {
    id: 'translate',
    ico: '✏️',
    title: 'Translation Studio',
    body: 'Where the English is made. Each verse sits over its Hebrew tokens with their glosses; a rendering is edited word by word and kept with its history, so the English can always be traced back to the Hebrew that produced it.',
    links: [{ to: '/translate?book=1&chapter=1&verse=1', label: 'Translation Studio — BaRaashayath 1:1' }],
  },
  {
    id: 'works',
    ico: '📚',
    title: 'Works Library',
    body: 'Books beyond the canon and studies built on it, read in the same reader with the same names.',
    links: [{ to: '/works', label: 'Works Library' }],
  },
];

export default function Guide() {
  usePageTitle(pageTitle('Guide'), 'What BLD Bible does and where to find it — the Novel English Bible, the paleo-Hebrew reader, the Parallel Bible, the Interactive Story Models and Maps, Passages, Precepts, the Lexicon and the Translation Studio.');
  return (
    <div className="guide">
      <header className="guide-top">
        <Link to="/landing" className="guide-back" title="Home">←</Link>
        <h1 className="guide-h1">Guide</h1>
        <span className="guide-kicker">What the app does, and where</span>
      </header>
      <nav className="guide-toc" aria-label="Sections">
        {SECTIONS.map((s) => <a key={s.id} href={`#${s.id}`}><span aria-hidden="true">{s.ico}</span> {s.title}</a>)}
      </nav>
      <div className="guide-sections">
        {SECTIONS.map((s) => (
          <section key={s.id} id={s.id} className="guide-section">
            <div className="guide-ico" aria-hidden="true">{s.ico}</div>
            <div className="guide-body">
              <h2>{s.title}</h2>
              <p>{s.body}</p>
              <div className="guide-links">
                {s.links.map((l) => <Link key={l.to} to={l.to} className="guide-link">{l.label} →</Link>)}
              </div>
            </div>
          </section>
        ))}
      </div>
      <footer className="guide-foot">
        Under the hood: the Hebrew text is tagged word by word (BHS), and the reader shows those tags when you open a word.
        The grammar of every tag is in the <Link to="/cheatsheet">Token Cheatsheet</Link>.
      </footer>
    </div>
  );
}
