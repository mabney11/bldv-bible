/**
 * Models.jsx — "Maps & Models": the index of interactive 3D / visual
 * models in the app. Linked from the landing page. Each model is its own
 * lazy route (see App.jsx); this page is just the catalogue, so adding a
 * model is one entry in MODELS below plus its route.
 *
 * Routes: /models (Interactive Story Models) and /maps (Maps) — the same catalogue split by `kind`; a catalogue with three views (posters: a thumbnail with the paleo name and the title, like a film app;
 * a list: one row a model, its stories as links; cards: the full blurbs) and a search box, for when the list is long.
 * Thumbnails: public/model-thumbs/<slug>.jpg (a frame of the model, 800 × 500).
 */
import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { pageTitle } from '../hooks/usePageTitle.js';
import { useModelSeo } from '../lib/models/seo.js';
import './Models.css';

export const MODELS = [
  {
    slug: 'holy-land',
    kind: 'map',
    title: 'The Holy Land in 3D',
    kicker: 'Interactive terrain map',
    blurb: 'Fly over the Levant in 3D relief. Switch between the tribal allotments of Joshua 13–19 and the millennial allotments of Ezekiel 47–48, see the biblical cities of Joshua with their paleo-Hebrew names, and find out which portion today\'s cities and peoples fall in.',
    paleo: '𐤉𐤁𐤍-𐤀𐤋',
    tags: ['Joshua 13–19', 'Ezekiel 47–48', '3D terrain', 'Cities'],
    to: '/models/holy-land',
    quick: [
      { label: 'Joshua allotments', to: '/models/holy-land?overlay=joshua' },
      { label: 'Millennial kingdom', to: '/models/holy-land?overlay=ezekiel' },
      { label: 'Jabneel — Joshua 15:11', to: '/models/holy-land?city=jabneel-judah' },
    ],
  },
  {
    slug: 'statue',
    kind: 'story',
    title: 'The Tzalam (Likeness) of the Dream',
    kicker: 'Interactive 3D model · Daniel 2',
    blurb: 'Nabawakadanaatzar (Nebuchadnezzar)\'s tzalam (likeness) — the raash (head) of dahab (gold), the chaday (breast) and darai (arms) of kasap (silver), the maih (belly) and yarakaa (thighs) of nachash (brass), the shaq (legs) of parazal (iron), the ragal (feet) of parazal (iron) and chasap (clay) — and the aban (stone) gazar (cut) out laa (without) yadayan (hands). Tap any piece for the text\'s own words and verses; play the aban (stone) striking it to pieces, scrub through the fall, and see that only the aban (stone) remains.',
    paleo: '𐤑𐤋𐤌 𐤀𐤁𐤍',
    tags: ['Daniel 2:31–45', 'Daniel 7–8', '3D · 2D sheet', 'Animation'],
    to: '/models/statue',
    quick: [
      { label: 'The aban (stone) — Daniel 2:34', to: '/models/statue?piece=stone' },
      { label: 'The ragal (feet) of parazal (iron) and chasap (clay)', to: '/models/statue?piece=feet' },
      { label: 'Flat 2D sheet', to: '/models/statue?view=2d' },
    ],
  },
  {
    slug: 'temple',
    kind: 'story',
    title: 'The Bayath (House) of Yahawah',
    kicker: 'Interactive 3D model · 1 Kings 6–7',
    blurb: 'The bayath (house) Shalamah (Solomon) banah (built) for Yahawah, measured in amah (cubits) from the text: the hayakal (temple) and the dabayar (oracle) with its karawab (cherubim), the awalam (porch), Yakayan (Jachin) and Baiz (Boaz), the yam (sea) on twelve oxen, the ten makanawath (bases), the mazabach (altar), the chatzarawath (courts) and the malak (king)\'s houses. Three stories on one model: watch it rise in the order 1 Kings 6–7 gives it, see it dedicated (1 Kings 8), or walk in from the gate to the arawan (ark); tap any part for its measures, verse by verse.',
    paleo: '𐤁𐤉𐤕 𐤉𐤄𐤅𐤄',
    tags: ['1 Kings 6–8', '2 Chronicles 3–7', '3D · plan & section', 'Build · Dedicate · Walk'],
    to: '/models/temple',
    quick: [
      { label: 'Build — watch it rise (1 Kings 6–7 in order)', to: '/models/temple/build' },
      { label: 'Dedicate — the ark, the inan (cloud), the ash (fire) (1 Kings 8)', to: '/models/temple/dedicate' },
      { label: 'Walk in, gate to ark', to: '/models/temple/walk' },
      { label: 'Roam it on your own feet', to: '/models/temple/roam' },
      { label: 'The karawab (cherubim) of the dabayar (oracle)', to: '/models/temple/walk?piece=karawab' },
      { label: 'Yakayan (Jachin) and Baiz (Boaz)', to: '/models/temple/walk?piece=pillars' },
    ],
  },
  {
    slug: 'ezekiel',
    kind: 'story',
    title: 'The Bayath (House) Yachazaqaal (Ezekiel) Saw',
    kicker: 'Interactive 3D model · Ezekiel 40–43',
    blurb: 'The bayath (house) shown to Yachazaqaal (Ezekiel) on the gabah (high) har (mountain), measured in the long amah (cubit) of the man\'s qanah (reed): the chawamah (wall) chamash (five) maah (hundred) square, the shairayam (gates) with their lodges and ayalayam (posts), the chatzarawath (courts), the mazabach (altar) with its Har\'Al, the awalam (porch), the hayakal (temple) and the most qadash (holy) place, the tzalai (side) rooms, the banayan (building) and the kahanayam (priests)\' rooms. Walk it the way he was led, or on your own feet.',
    paleo: '𐤁𐤉𐤕 𐤉𐤇𐤆𐤒𐤀𐤋',
    tags: ['Ezekiel 40–43', '3D · plan & section', 'Walk · On foot'],
    to: '/models/ezekiel',
    quick: [
      { label: 'Walk — the way the man with the qanah (reed) led him', to: '/models/ezekiel/walk' },
      { label: 'Roam it on your own feet', to: '/models/ezekiel/roam' },
      { label: 'The east shair (gate) — Ezekiel 40:6–16', to: '/models/ezekiel/walk?piece=gate-east' },
      { label: 'The mazabach (altar) — Ezekiel 43:13–17', to: '/models/ezekiel/walk?piece=mazabach' },
    ],
  },
  {
    slug: 'tabernacle',
    kind: 'story',
    title: 'The Mashakan (Tabernacle) and Its Machanah (Camp)',
    kicker: 'Interactive 3D model · Exodus 25–27, 40 · Numbers 2',
    blurb: 'The mashakan (tabernacle) measured in amah (cubits) from the text: the chatzar (court) of qalaiyam (hangings) a hundred by fifty on its sixty imawadayam (pillars), the mazabach (altar) of nachashath (brass) and the basin, the qarashayam (boards) overlaid with zahab (gold) in adanayam (sockets) of kasap (silver), the yarayaihath (curtains) with karawab (cherubim) and the ahal (tent) of izayam (goats)\' hair over them, the shalachan (table), the manawarah (lampstand), the mazabach (altar) of qatarath (incense), the parakath (veil) and the arawan (ark) — with the Lawayay (Levites) and the twelve tribes camped about it by their dagal (standards). Raise it in the order Mashah (Moses) did, or walk it on your own feet.',
    paleo: '𐤌𐤔𐤊𐤍',
    tags: ['Exodus 25–27, 40', 'Numbers 2–3', '3D · plan & section', 'Raise · On foot'],
    to: '/models/tabernacle',
    quick: [
      { label: 'Raise — in the order Mashah (Moses) set it up', to: '/models/tabernacle/walk' },
      { label: 'Roam it and the camp on your own feet', to: '/models/tabernacle/roam' },
      { label: 'The arawan (ark) — Exodus 25:10–22', to: '/models/tabernacle/walk?piece=arawan' },
      { label: 'The machanah (camp) of Yahawadah (Judah) — Numbers 2:3', to: '/models/tabernacle/walk?piece=judah' },
    ],
  },
  {
    slug: 'ezekiel-city',
    kind: 'story',
    title: 'The Iyar (City) Yachazaqaal (Ezekiel) Saw and the Holy Portion',
    kicker: 'Interactive 3D model · Ezekiel 45 · 47 · 48',
    blurb: 'The iyar (city) of Ezekiel 48 and the qadash (holy) tharawamah (portion) it stands in, measured in amah (cubits) from the text: the portion twenty-five alap (thousand) square with the kahanayam (priests)\' strip and the bayath (house) — the house model itself — in its midst, the Lawayay (Levites)\' strip and the city\'s; the city four thousand five hundred a side with its magarash (open land) and twelve shairayam (gates) named for the shabatay (tribes); the nashayaa (prince)\'s land, the tribes\' strips north and south, and the nachal (river) from the house. Lay it out from above, or walk the city on your own feet.',
    paleo: '𐤉𐤄𐤅𐤄 𐤔𐤌𐤄',
    tags: ['Ezekiel 45 · 47 · 48', '3D · plan & section', 'Portion · City · On foot'],
    to: '/models/ezekiel-city',
    quick: [
      { label: 'Portion — the land divided, from above', to: '/models/ezekiel-city/portion' },
      { label: 'City — the wall and the twelve gates', to: '/models/ezekiel-city/city' },
      { label: 'Walk its streets on your own feet', to: '/models/ezekiel-city/roam' },
      { label: 'The nachal (river) from the house — Ezekiel 47:1–12', to: '/models/ezekiel-city/portion?piece=nachal' },
    ],
  },
  {
    slug: 'revelation-city',
    kind: 'story',
    title: 'The Shairay (City) Coming Down Out of Shamayam (Heaven)',
    kicker: 'Interactive 3D model · Revelation 21–22',
    blurb: 'The qadash (holy) shairay (city), New Yarawashalam, at the text\'s own scale — twelve thousand stadia a side and as high, coming down over the Holy Land map\'s own land on the same ground as Yachazaqaal\'s city: its wall of yashapah (jasper) a hundred and forty-four amah on twelve adanay (foundations) of twelve stones, its twelve shairayam (gates) each one pearl with a malaak (angel) at it, the rachab (street) of zahab (gold), the nahar (river) of the water of chay (life) from the kasaa (throne) and the ayalan (tree) of life on either side. Watch it come down, or stand in its gate on your own feet and be carried to the throne.',
    paleo: '𐤉𐤓𐤅𐤔𐤋𐤌 𐤇𐤃𐤔𐤄',
    tags: ['Revelation 21–22', '3D · plan & section', 'Descend · On foot'],
    to: '/models/revelation-city',
    quick: [
      { label: 'Descend — the city comes down, verse by verse', to: '/models/revelation-city/descend' },
      { label: 'Stand in its gate on your own feet', to: '/models/revelation-city/roam' },
      { label: 'The twelve adanay (foundations) — Revelation 21:19–20', to: '/models/revelation-city/descend?piece=yasawad-1' },
      { label: 'The nahar (river) of the water of chay (life) — Revelation 22:1–2', to: '/models/revelation-city/descend?piece=nahar' },
    ],
  },
  {
    slug: 'prints',
    kind: 'map',
    title: 'Printable Maps',
    kicker: 'Downloadable map sheets',
    blurb: 'The Holy Land as official-looking map sheets, drawn from the same data as the 3D model: the allotment of Ezekiel 47–48 with the Holy Portion and the prince\'s land, the allotment of Joshua 13–19, and the Holy Portion close up. Save as a print-quality PNG, an SVG, or a PDF.',
    paleo: '𐤀𐤓𐤑 𐤒𐤃𐤔',
    tags: ['Ezekiel 47–48', 'Joshua 13–19', 'PNG · SVG · PDF'],
    to: '/models/prints',
    quick: [
      { label: 'Ezekiel\'s allotment', to: '/models/prints?map=ezekiel' },
      { label: 'Joshua\'s allotment', to: '/models/prints?map=joshua' },
      { label: 'The Holy Portion', to: '/models/prints?map=holy' },
    ],
  },
];


const VIEWS = [['posters', 'Posters'], ['list', 'List'], ['cards', 'Cards']];
const norm = (t) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
/** every word of a model's text, for the search */
const haystack = (m) => norm([m.title, m.kicker, m.blurb, m.slug, ...(m.tags || []), ...(m.quick || []).map((q) => q.label)].join(' '));

function Thumb({ m }) {
  const [broken, setBroken] = useState(false);
  return (
    <span className={`models-thumb${broken ? ' models-thumb-none' : ''}`} aria-hidden="true">
      {!broken && <img src={`/model-thumbs/${m.slug}.jpg`} alt="" loading="lazy" onError={() => setBroken(true)} />}
      <span className="models-thumb-paleo">{m.paleo}</span>
    </span>
  );
}

/** Story Models (/models) and Maps (/maps) are one catalogue split by `kind` —
 *  fieldy, 2026-09-29: "Interactive Story Models — i can anticipate this getting
 *  big so i want to separate it from maps". Each keeps its own count, search and
 *  views; the header links across to the other. */
const KINDS = {
  story: { h1: 'Interactive Story Models', to: '/models', other: { to: '/maps', label: 'Maps →' }, noun: ['model', 'models'],
    intro: 'The stories of scripture in 3D, built from the text — measured in amah (cubits) where the text gives measures, raised and walked in the order the text gives them. Watch it happen verse by verse, or roam it on your own feet. More will be added here over time.',
    placeholder: 'Search — temple, tabernacle, Ezekiel, gate, Revelation 21…' },
  map: { h1: 'Maps', to: '/maps', other: { to: '/models', label: 'Story Models →' }, noun: ['map', 'maps'],
    intro: 'The land drawn from the text — the twelve shabatay (tribes) of Yashar-Al (Israel) in 3D relief, the allotments of Yahawashawai (Joshua) and Yachazaqaal (Ezekiel), the cities, rivers and seas under the names the Bible gives them, and printable sheets.',
    placeholder: 'Search — Ezekiel 48, Joshua, tribes, Holy Portion…' },
};

export default function Models({ kind = 'story' }) {
  const K = KINDS[kind] || KINDS.story;
  const ALL = useMemo(() => MODELS.filter((m) => (m.kind || 'story') === kind), [kind]);
  useModelSeo(pageTitle(K.h1));
  const [view, setView] = useState(() => { try { return localStorage.getItem('models-view') || 'posters'; } catch { return 'posters'; } });
  const [q, setQ] = useState('');
  useEffect(() => { try { localStorage.setItem('models-view', view); } catch { /* private mode */ } }, [view]);
  const words = norm(q).split(/\s+/).filter(Boolean);
  const shown = useMemo(() => (words.length ? ALL.filter((m) => { const h = haystack(m); return words.every((w) => h.includes(w)); }) : ALL), [words.join(' '), ALL]);
  return (
    <div className="models-page">
      <header className="models-top">
        <Link to="/landing" className="models-back" title="Home">←</Link>
        <h1 className="models-h1">{K.h1}</h1>
        <span className="models-count">{words.length ? `${shown.length} of ${ALL.length}` : `${ALL.length} ${K.noun[ALL.length === 1 ? 0 : 1]}`}</span>
        <Link to={K.other.to} className="models-other">{K.other.label}</Link>
      </header>
      <p className="models-intro">{K.intro}</p>
      <div className="models-bar">
        <label className="models-search">
          <span aria-hidden="true">⌕</span>
          <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder={K.placeholder} aria-label={`Search the ${K.noun[1]}`} />
          {q && <button type="button" className="models-search-x" onClick={() => setQ('')} aria-label="Clear">×</button>}
        </label>
        <div className="models-views" role="tablist" aria-label="View">
          {VIEWS.map(([k, label]) => <button key={k} type="button" role="tab" aria-selected={view === k} className={`models-view${view === k ? ' on' : ''}`} onClick={() => setView(k)}>{label}</button>)}
        </div>
      </div>
      {!shown.length && <p className="models-none">Nothing here for “{q}” — try a book, a word from the text, or a part (gate, altar, ark).</p>}

      {view === 'posters' && (
        <div className="models-posters">
          {shown.map((m) => (
            <Link key={m.slug} to={m.to} className="models-poster" title={m.title}>
              <Thumb m={m} />
              <span className="models-poster-text">
                <span className="models-poster-kicker">{m.kicker}</span>
                <span className="models-poster-title">{m.title}</span>
              </span>
            </Link>
          ))}
        </div>
      )}

      {view === 'list' && (
        <div className="models-list" role="list">
          {shown.map((m) => (
            <div key={m.slug} className="models-row" role="listitem">
              <Link to={m.to} className="models-row-paleo" aria-hidden="true">{m.paleo}</Link>
              <div className="models-row-main">
                <Link to={m.to} className="models-row-title">{m.title}</Link>
                <span className="models-row-kicker">{m.kicker}</span>
                <span className="models-row-links">{m.quick.map((qk) => <Link key={qk.to} to={qk.to}>{qk.label}</Link>)}</span>
              </div>
              <div className="models-row-tags">{m.tags.map((t) => <span key={t}>{t}</span>)}</div>
              <Link to={m.to} className="models-row-open">Open →</Link>
            </div>
          ))}
        </div>
      )}

      {view === 'cards' && (
      <div className="models-grid">
        {shown.map((m) => (
          <article key={m.slug} className="models-card">
            <Link to={m.to} className="models-card-hero">
              <span className="models-card-paleo" aria-hidden="true">{m.paleo}</span>
              <span className="models-card-kicker">{m.kicker}</span>
              <span className="models-card-title">{m.title}</span>
            </Link>
            <p className="models-card-blurb">{m.blurb}</p>
            <div className="models-card-tags">{m.tags.map((t) => <span key={t}>{t}</span>)}</div>
            <div className="models-card-quick">
              <Link to={m.to} className="models-card-open">Open model →</Link>
              {m.quick.map((qk) => <Link key={qk.to} to={qk.to} className="models-card-q">{qk.label}</Link>)}
            </div>
          </article>
        ))}
        {!words.length && kind === 'story' && (
        <div className="models-card models-card-soon">
          <span className="models-card-kicker">Coming</span>
          <span className="models-card-title">More models</span>
          <p className="models-card-blurb">Future renderings — Noah's thabah (ark) and the flood, the tower of Babel, the camp on the march, the three in the furnace, Daniel in the lions' den — will appear here as they're built.</p>
        </div>
        )}
      </div>
      )}
    </div>
  );
}
