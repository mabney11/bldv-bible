/**
 * ModelPage.jsx — a measured model's page, whatever the model (the bayath of
 * Yahawah, Yachazaqaal's house, the mashakan, a city): its stories as branch
 * pages, the WebGL scene or the flat sheet, the player, the chips, the panel
 * with the text and the card for a part. Everything that names the model comes
 * from its MODEL object (lib/models/*.js): the title, the stories, the card's
 * prose, the passages, the pieces. pages/Temple.jsx is one line on this.
 *
 * Route: <base>/:story   ?piece=<id>  ?view=3d|2d   (<base> itself is the chooser, ModelIndex.jsx)
 *
 * - Stories on ONE model: a guided story (the camera and the captions follow the
 *   text; the scrub bar moves it), and ROAM, no story: the finished model, the
 *   viewer walking where they will (drag to look, keys or the pad to walk, a
 *   door tapped twice opens and lets them through).
 * - Two renderers of it: the WebGL scene (three.js, lazy) and the flat sheet
 *   (a plan and a section, no library, the fallback without WebGL).
 * - The panel opens on the TEXT with every word that names a part clickable;
 *   choosing a part by any route (the model, a chip, a word) lights its words
 *   and edges its verses.
 * - The card for a part: its words (transliteration, paleo, meaning), what the
 *   text measures (each measure with its verse), the same thing elsewhere in
 *   scripture, and — plainly — what the text does not say and the model assumed.
 */
import { Suspense, lazy, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, Navigate, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { pageTitle } from '../hooks/usePageTitle.js';
import { useModelSeo } from '../lib/models/seo.js';
import { PassageRefs, Glossed } from '../components/PassageRefs.jsx';
import { usePlayer, Section, WordRow, ModelPassage, Caption, PaceSelect, CanvasSubtitles, CanvasTitle, SubtitlesToggle, useSubtitles } from '../components/ModelKit.jsx';
import ModelSheet from '../components/ModelSheet.jsx';
import { STORY_ICONS } from '../components/ModelStories.jsx';
import './Temple.css';

const ModelScene = lazy(() => import('../components/ModelScene.jsx'));

function webglAvailable() {
  try { const c = document.createElement('canvas'); return !!(window.WebGLRenderingContext && (c.getContext('webgl2') || c.getContext('webgl'))); }
  catch { return false; }
}
const VIEWS = ['3d', '2d'];
const COARSE = typeof matchMedia === 'function' && matchMedia('(pointer: coarse)').matches;   // a touch screen
const timelinesOf = (model) => Object.fromEntries(Object.keys(model.MODES).map((k) => [k, { key: k, duration: model.MODES[k].duration, phases: model.MODES[k].phases, phaseAt: (t) => model.phaseAt(k, t) }]));

// ── Detail card ──────────────────────────────────────────────────────────────
function Card({ model, id, mode, onClose, onPick }) {
  const { WORDS, GROUPS, pieceById, pieceForWord, passagesFor, refsFor, card } = model;
  const item = pieceById(id);
  const onVerses = useMemo(() => new Set(item ? item.on : []), [item]);
  const pieceFor = useCallback((w, p, n) => pieceForWord(w, p.bookId, p.chapter, n), [pieceForWord]);
  const titleFor = useCallback((pid) => pieceById(pid)?.title, [pieceById]);
  const extras = (!item && card.extras?.(mode)) || [];
  return (
    <div className="st-card">
      {item ? (
        <>
          <div className="st-card-h">
            <div className="st-detail-sub"><Glossed text={GROUPS[item.group]} /> · {item.refs}</div>
            <h2 className="st-card-title"><Glossed text={item.title} /></h2>
            <button type="button" className="st-card-x" onClick={onClose} aria-label="Close">×</button>
          </div>
          <div className="st-words">
            {item.words.map((k) => WORDS[k] && <WordRow key={k} w={WORDS[k]} />)}
          </div>
        </>
      ) : (
        <div className="st-card-h">
          <div className="st-detail-sub">{card.subtitle(mode)}</div>
          <h2 className="st-card-title"><Glossed text={card.title} /></h2>
          <p className="st-card-p"><Glossed text={card.intro(mode)} /></p>
        </div>
      )}

      <Section id="scripture" title="Scripture" sub={`${card.subtitle(mode)} · the text itself`} storageKey="tp-sec">
        <ModelPassage passages={passagesFor(mode)} selected={id} onPick={onPick} onVerses={onVerses} pieceFor={pieceFor} titleFor={titleFor} allRefs={refsFor(mode)} />
      </Section>

      <Section id="details" title="Details" sub={item ? 'what the text measures · elsewhere in scripture · what is assumed' : 'choose a part'} storageKey="tp-sec">
        {!item && <p className="st-card-p">{card.choose || 'Tap a part of the model, one of the chips under it, or a marked word in the text for its measures, verse by verse, the same thing elsewhere in scripture, and what the model had to assume where the text is silent.'}</p>}
        {extras.map((x) => (
          <div key={x.heading}>
            <div className="st-detail-sub">{x.heading}</div>
            <div className="st-par">
              <p><Glossed text={x.text} /></p>
              <PassageRefs refs={x.refs} size="sm" />
            </div>
          </div>
        ))}
        {item && (
          <>
            <div className="st-detail-sub">What the text gives</div>
            <table className="tp-measures">
              <tbody>
                {item.measures.map(([k, v, ref], i) => (
                  <tr key={i}><th><Glossed text={k} /></th><td><Glossed text={v} /></td><td className="tp-measures-ref">{ref}</td></tr>
                ))}
              </tbody>
            </table>
            <p className="st-card-p tp-note"><Glossed text={item.note} /></p>
            <PassageRefs refs={item.refs} size="sm" />

            <div className="st-detail-sub">Elsewhere in scripture</div>
            <div className="st-par">
              <p><Glossed text={item.elsewhere.note} /></p>
              <PassageRefs refs={item.elsewhere.ref} size="sm" />
            </div>

            <div className="st-detail-sub">Not in the text <em>(what the model assumed)</em></div>
            <p className="st-trad"><Glossed text={item.assumed} /></p>
            {item.idealized && (<>
              <div className="st-detail-sub tp-ideal-sub"><span className="tp-ideal-swatch" aria-hidden="true" />Idealized <em>(sketched in, paled and see-through on the model)</em></div>
              <p className="st-trad"><Glossed text={item.idealized} /></p>
            </>)}
          </>
        )}
      </Section>
    </div>
  );
}

// ── The page ─────────────────────────────────────────────────────────────────
/** The reader's own figure — the robed, faceless walker of every model, legless as in the model, the robe to the ground — in
 *  right-side silhouette, running to the right and leaning further forward the faster the pace, the wind streaking behind
 *  (fieldy's sketch: one, two or three streaks; "we don't show his legs in the app so the figure doesn't need them either"). */
function RunnerIcon({ wind = 0 }) {
  const lean = 6 + wind * 9;   // degrees forward (clockwise: the top of the figure moves to the right, the way it runs)
  return (
    <svg viewBox="0 0 46 36" width="46" height="36" aria-hidden="true" className="tp-runner">
      <g stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" opacity="0.8">
        {wind >= 0 && <path d="M4 14 L14 14" />}
        {wind >= 1 && <path d="M2 20 L15 20" />}
        {wind >= 2 && <path d="M5 26 L16 26" />}
      </g>
      <g transform={`rotate(${lean} 28 33)`} fill="currentColor" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round">
        <ellipse cx="28.6" cy="6.2" rx="3.6" ry="3.9" stroke="none" />                       {/* the head, with the hair's fullness */}
        <path d="M25.6 5.2 C24.4 3.2 27.4 1.6 30.2 2.4 C32.4 3 32.8 5.4 32 7 C31.6 5 29 4.4 27.2 5.6 Z" stroke="none" />   {/* the hair over the band */}
        <path d="M26 10 L31.4 10 L33.2 19 C34.6 24 36.4 29 37 32 L19 32 C19.8 29 21.6 24 23.6 19 Z" stroke="none" />       {/* the robe, flaring to the ground */}
        <path d="M18.4 32.4 L37.6 32.4" fill="none" strokeWidth="2.6" />                     {/* the robe's foot, flat on the ground */}
        <path d="M31 12.6 L37.4 15 L40 10.4" fill="none" strokeWidth="2.4" />                {/* the leading arm, forward */}
        <path d="M26.4 12.4 L21.4 16.6" fill="none" strokeWidth="2.4" />                     {/* the trailing arm */}
        <path d="M23.2 20.6 L33.6 20.6" fill="none" strokeWidth="1.2" stroke="var(--bg, #14100a)" opacity="0.9" />   {/* the sash */}
      </g>
    </svg>
  );
}

export default function ModelPage({ model }) {
  const { MODES, SPEEDS, CHIP_ORDER, pieceById, marksFor, base, strings = {} } = model;
  useModelSeo(pageTitle(`${model.title} — Interactive Story Models`), model.description);
  const TIMELINES = useMemo(() => timelinesOf(model), [model]);
  const PIECE_IDS = useMemo(() => model.PIECES.map((p) => p.id), [model]);
  const [params] = useSearchParams();
  const { story } = useParams();
  const canGL = useMemo(webglAvailable, []);
  const view = VIEWS.includes(params.get('view')) ? params.get('view') : (canGL ? '3d' : '2d');
  const mode = MODES[story] ? story : model.defaultStory;
  useEffect(() => { if (MODES[story]) { try { sessionStorage.setItem(`${model.id}-story`, story); } catch { /* fine */ } } }, [story, model.id]);
  const [lock, setLock] = useState(null);   // on foot: { on, why } — a word under the view on whether the mouse is taken
  const [glOk, setGlOk] = useState(true);
  const sel = PIECE_IDS.includes(params.get('piece')) ? params.get('piece') : null;
  const sceneApi = useRef(null);
  // "tap to go on" also brings the view back to where the story is: what the next caption tells is then in front of the reader
  const player = usePlayer(TIMELINES[mode], { onContinue: () => sceneApi.current?.follow?.() });
  const { clock, playing, speed, setSpeed, loop, setLoop, phase, play, pause, seek, restart, scrubRef, timeRef, hold, continueNow } = player;
  const [sheetOpen, setSheetOpen] = useState(!!sel);
  const [sheetTall, setSheetTall] = useState(false);   // on foot the sheet stays low so the view stays in sight (fieldy); a drag up on its grip makes it tall
  const [following, setFollowing] = useState(true);
  const subs = useSubtitles();
  const [scrubbed, setScrubbed] = useState(null);   // the pane the reader scrubbed to: its subtitles run though the story is not playing   // the caption spoken into the scene, word by word

  const navigate = useNavigate();
  const setParam = useCallback((k, v) => {
    const q = new URLSearchParams(params);
    if (v == null || v === '') q.delete(k); else q.set(k, v);
    // the story's own absolute path, never a relative "?…" — on foot must stay on foot whatever is picked
    navigate(`${base}/${MODES[story] ? story : model.defaultStory}${q.toString() ? `?${q}` : ''}`, { replace: true });
  }, [params, navigate, story, base, MODES, model.defaultStory]);
  const select = useCallback((id) => { setParam('piece', id); setSheetOpen(!!id); }, [setParam]);

  const panelRef = useRef(null), grip = useRef(null);
  const onGripDown = (e) => { if (e.target.closest('button')) return; grip.current = { y: e.clientY, dy: 0 }; e.currentTarget.setPointerCapture?.(e.pointerId); if (panelRef.current) panelRef.current.style.transition = 'none'; };
  const onGripMove = (e) => { const g = grip.current; if (!g) return; g.dy = e.clientY - g.y; if (panelRef.current) panelRef.current.style.transform = `translateY(${Math.max(0, g.dy)}px)`; };
  const onGripUp = () => { const g = grip.current; if (!g) return; grip.current = null; const el = panelRef.current; if (el) { el.style.transition = ''; el.style.transform = ''; } if (g.dy > 70) { if (sheetTall) setSheetTall(false); else setSheetOpen(false); } else if (g.dy < -40) setSheetTall(true); };

  useEffect(() => { document.body.classList.add('st-body'); return () => document.body.classList.remove('st-body'); }, []);

  const use3d = view === '3d' && canGL && glOk;
  // the walker's pace on foot: the usual walk, faster, much faster — with the speed in miles an hour at the model's cubit, so
  // the size of the place is felt (fieldy: "a mi/hr reference in scale to the city")
  const PACES = [1, 3, 8], CUBIT = model.cubit || 0.457, WALK_CUBITS = 32;
  const [paceMul, setPaceMul] = useState(() => { try { const v = +localStorage.getItem('model-pace-mul'); return PACES.includes(v) ? v : 1; } catch { return 1; } });
  useEffect(() => { sceneApi.current?.pace?.(paceMul); try { localStorage.setItem('model-pace-mul', String(paceMul)); } catch {} }, [paceMul, mode, use3d]);   // eslint-disable-line react-hooks/exhaustive-deps
  const mph = (m) => Math.round(WALK_CUBITS * m * CUBIT * 2.23694);
  const TIMES = model.scene?.times || null;   // a model whose sky keeps the hour offers day or night on foot (the mashakan)
  const timeOfDay = TIMES && TIMES.includes(params.get('time')) ? params.get('time') : (TIMES ? TIMES[0] : 'day');
  const D = MODES[mode].duration;
  const roam = !!MODES[mode].free;
  const onPlayPause = () => (playing ? pause() : play());
  // Moving the timeline hands the camera back to the story: whatever the viewer
  // had picked or dragged to, a scrub means "show me what happens here". A still
  // slider leaves their selection and free look alone.
  const rejoin = useCallback(() => { if (sel) select(null); if (!following) sceneApi.current?.follow?.(); }, [sel, following, select]);
  const seekAlong = useCallback((t) => { rejoin(); seek(t); setScrubbed(TIMELINES[mode].phaseAt(Math.max(0, Math.min(D, t))).key); }, [rejoin, seek, TIMELINES, mode, D]);
  const onScrub = (e) => seekAlong((+e.target.value / 1000) * D);
  const onRestart = () => { rejoin(); restart(); };
  useEffect(() => {
    const onKey = (e) => {
      if (/^(INPUT|SELECT|TEXTAREA|BUTTON)$/.test(e.target.tagName) || e.metaKey || e.ctrlKey) return;
      if (roam) return;   // the roam has the keys (walking)
      if (e.key === 'Enter' && hold) { e.preventDefault(); continueNow(); return; }
      if (e.key === ' ') { e.preventDefault(); if (hold) continueNow(); else playing ? pause() : play(); }
      else if (e.key === 'ArrowLeft') seekAlong(clock.t - 0.5);
      else if (e.key === 'ArrowRight') seekAlong(clock.t + 0.5);
      else if (e.key === 'Home') seekAlong(0);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });
  const marks = useMemo(() => marksFor(mode), [mode, marksFor]);
  const storyOf = model.stories.find((s) => s.modes.includes(mode)) || model.stories[model.stories.length - 1];
  const StoryIcon = STORY_ICONS[storyOf.icon] || STORY_ICONS.walk;
  const walkPair = storyOf.modes.filter((k) => MODES[k]);   // [guided, roam] when the story has both
  if (!MODES[story]) { let last = null; try { last = sessionStorage.getItem(`${model.id}-story`); } catch { /* fine */ } return <Navigate to={MODES[last] ? `${base}/${last}${params.toString() ? `?${params}` : ''}` : `${base}${params.toString() ? `?${params}` : ''}`} replace />; }

  return (
    <div className={`st-page tp-page${sheetOpen ? ' st-sheet-open' : ''}${roam ? ' tp-roam' : ''}${sheetTall ? ' st-sheet-tall' : ''}`}>
      <header className="st-top">
        <Link to={base} className="st-back" title={strings.storiesTitle || 'The model\'s stories'}>←</Link>
        <nav className="tp-nav" aria-label="Elsewhere">
          <Link to="/landing" className="tp-nav-home" title="Home">𐤀𐤁</Link>
          <Link to="/models" title="Interactive Story Models — the other models">Models</Link>
        </nav>
        <div className="st-h1wrap">
          <h1 className="st-h1">{model.title}</h1>
          <span className="st-h1-paleo" dir="rtl" aria-hidden="true">{model.paleo}</span>
        </div>
        <span className="tp-top-break" aria-hidden="true" />
        <Link to={base} className="tp-story" title={`This story — tap for the others (${model.stories.map((s) => s.label).join(', ')})`}><StoryIcon width="22" height="22" /><span>{storyOf.label}</span></Link>
        {walkPair.length > 1 && (
          <div className="st-views tp-modes" role="group" aria-label="How to walk">
            {walkPair.map((k) => <Link key={k} to={`${base}/${k}${params.toString() ? `?${params}` : ''}`} className={`st-view${mode === k ? ' on' : ''}`} title={MODES[k].free ? 'On your own feet: go where you will' : (strings.guidedTitle || 'Guided: verse by verse')}>{MODES[k].free ? 'On foot' : 'Guided'}</Link>)}
          </div>
        )}
        <div className="st-views" role="group" aria-label="View">
          <button type="button" className={`st-view${use3d ? ' on' : ''}`} onClick={() => setParam('view', '3d')} disabled={!canGL || !glOk} title={canGL && glOk ? 'Lit 3D model — drag to look around' : 'WebGL is not available in this browser'}>3D</button>
          <button type="button" className={`st-view${!use3d ? ' on' : ''}`} onClick={() => setParam('view', '2d')} title="Plan and section — light, prints, works anywhere">2D</button>
        </div>
      </header>

      <div className="st-main">
        <section className="st-stagewrap">
          <div className="st-stagebox">
            <div className="st-stage tp-stage">
              {use3d
                ? <Suspense fallback={<div className="st-loading">Loading the 3D model…</div>}><ModelScene model={model} clock={clock} mode={mode} selected={sel} onSelect={select} onFollow={setFollowing} time={timeOfDay} onLock={(on, why) => setLock({ on, why, at: Date.now() })} apiRef={sceneApi} onReady={(ok) => { if (!ok) setGlOk(false); }} /></Suspense>
                : <ModelSheet model={model} clock={clock} mode={mode} selected={sel} onSelect={select} />}
              {use3d && roam && (
                <div className="tp-speeds" role="group" aria-label="Pace">
                  {[...PACES].reverse().map((m, i) => (
                    <button key={m} type="button" className={`tp-speed${paceMul === m ? ' on' : ''}`} onClick={() => setPaceMul(m)} title={`${m === 1 ? 'The usual walk' : m === 3 ? 'Faster' : 'Much faster'} — about ${mph(m)} miles an hour at a cubit of ${Math.round(CUBIT * 39.37)} inches`} aria-label={`${m === 1 ? 'Walk' : m === 3 ? 'Faster' : 'Much faster'}, about ${mph(m)} miles an hour`}>
                      <RunnerIcon wind={2 - i} />
                      <span className="tp-speed-mph">{mph(m)} <small>mi/h</small></span>
                    </button>
                  ))}
                </div>
              )}
              {use3d && roam && (
                <div className="tp-pad" aria-label="Walk">
                  {[['forward', '▲', 'Walk forward (W / ↑)'], ['turnL', '◀', 'Turn left (←)'], ['back', '▼', 'Walk back (S / ↓)'], ['turnR', '▶', 'Turn right (→)'], ['jump', '⤒', 'Jump (space)']].map(([k, ch, tt]) => (
                    <button key={k} type="button" className={`tp-pad-${k}`} title={tt} aria-label={tt}
                      onPointerDown={(e) => { e.preventDefault(); e.currentTarget.setPointerCapture?.(e.pointerId); sceneApi.current?.move?.(k, true); }}
                      onPointerUp={() => sceneApi.current?.move?.(k, false)} onPointerCancel={() => sceneApi.current?.move?.(k, false)} onLostPointerCapture={() => sceneApi.current?.move?.(k, false)}
                      onContextMenu={(e) => e.preventDefault()}>{ch}</button>
                  ))}
                </div>
              )}
              {!roam && <CanvasTitle phase={phase} on={subs.on} playing={playing} scrubbed={scrubbed} />}
              {!roam && <CanvasSubtitles phase={phase} clock={clock} timeline={TIMELINES[mode]} on={subs.on} playing={playing} scrubbed={scrubbed} report={(v) => { player.subs.current = v; }} />}
              {use3d && !roam && !following && <button type="button" className="tp-follow" onClick={() => sceneApi.current?.refocus?.()} title={sel ? 'Recentre on the chosen part' : 'Recentre on where the story is'}>⌖ refocus</button>}
              <div className="st-strip" role="toolbar" aria-label={strings.parts || 'Parts of the model'}>
                {CHIP_ORDER.map((id) => pieceById(id)).filter((p) => p && (!p.modes || p.modes.includes(mode))).map((p) => (
                  <button key={p.id} type="button" className={`st-chip${sel === p.id ? ' on' : ''}`} onClick={() => select(sel === p.id ? null : p.id)} title={p.title}>
                    <Glossed text={p.tag.split(' · ')[0]} />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {roam ? (
            <div className="st-player tp-roambar">
              {use3d && <button type="button" className="tp-reset" onClick={() => sceneApi.current?.reset?.()} title="Back to the start, outside the gate, every door and gate as at the first">↺ Start over</button>}
              {use3d && TIMES && (
                <div className="st-views tp-times" role="group" aria-label="Time of day">
                  {TIMES.map((tm) => <button key={tm} type="button" className={`st-view${timeOfDay === tm ? ' on' : ''}`} onClick={() => setParam('time', tm === TIMES[0] ? null : tm)} title={tm === 'night' ? 'By night: the fire in the cloud, the camps by their own light' : 'By day: the cloud on the tent'}>{tm === 'night' ? 'At night' : 'By day'}</button>)}
                </div>
              )}
              <span className="tp-roam-hint">{!use3d ? 'The plan and section show the finished model; switch to 3D to walk it.' : COARSE ? 'A thumb in the ring, bottom left: a stick to walk · a finger anywhere else: drag to look · two fingers: pinch to see yourself (and on, over the whole model — there the stick carries you where you look), spread to look through your eyes · ⤒ jumps · tap a part for its details, a door or a gate twice to open or shut it' : lock?.on ? 'The mouse is yours: move it to look, W A S D or the arrows to walk (Shift to run, space to jump), click what the crosshair is on for its details, a door or a gate twice to open or shut it · the wheel pulls the view back to see yourself — and on, high over the whole model with a light marking where you stand, where W A S D carry you through the air the way you look — forward again into your eyes, and you are set down · M shows the whole map: tap a place on it and you are walked there · Esc gives the mouse back' : lock?.why ? `The browser would not hand over the mouse (${lock.why}) — drag the view to look instead · W A S D or the arrows to walk · click a part for its details` : 'Click the view once to take the mouse (nothing is chosen by that click) · then move it to look, W A S D or the arrows to walk, ← → turn, Shift to run, space to jump · click what the crosshair is on for its details, a door or a gate twice to open or shut it · the wheel pulls the view back to see yourself (far back, W A S D carry you where you look) · M shows the whole map: tap a place on it and you are walked there · Esc gives the mouse back'}</span>
            </div>
          ) : (
          <div className="st-player">
            <button type="button" className="st-play" onClick={onPlayPause} aria-label={playing ? 'Pause' : 'Play'}>{playing ? '❚❚' : '▶'}</button>
            <button type="button" className="st-restart" onClick={onRestart} aria-label="Play from the beginning" title="From the beginning">↺</button>
            <div className="st-scrubwrap">
              <input ref={scrubRef} id="tp-scrub" type="range" min="0" max="1000" defaultValue="0" step="1" onInput={onScrub} className="st-scrub" aria-label={`Scrub through the ${storyOf.label.toLowerCase()}`} />
              <div className="st-marks tp-marks" aria-hidden="true">
                {marks.map((m) => <span key={m.label + m.at} className={m.at < 0.05 ? 'st-mark-l' : m.at > 0.95 ? 'st-mark-r' : ''} style={{ left: `${m.at * 100}%` }}>{m.label}</span>)}
              </div>
            </div>
            <span ref={timeRef} className="st-time">0.0 s</span>
            <div className="st-opts">
              <label className="st-speed">
                <span>speed</span>
                <select id="tp-speed" value={speed} onChange={(e) => setSpeed(+e.target.value)}>
                  {SPEEDS.map((s) => <option key={s} value={s}>{s === 0.25 ? '¼×' : s === 0.5 ? '½×' : `${s}×`}</option>)}
                </select>
              </label>
              <PaceSelect player={player} id="tp-pace" />
              <label className="st-loop"><input id="tp-loop" type="checkbox" checked={loop} onChange={(e) => setLoop(e.target.checked)} /> repeat</label>
              <SubtitlesToggle subs={subs} id="tp-subs" />
            </div>
          </div>
          )}
          <Caption player={player} phase={phase} render={(t) => <Glossed text={t} />} />
          <p className="st-hint">{use3d && !roam ? 'Left-drag to orbit, scroll to zoom, right-drag to pan — the view only moves when you move it. A click on a part opens its card where you stand; a chip or a word flies to it; move the timeline, or tap to go on, and the story takes the camera back; "refocus" recentres. ' : ''}<Glossed text="Tap a part, a chip under it, or a word in the text for its measures and verses — one amah (cubit) in the text is one unit in the model." /></p>
          <button type="button" className="st-openbtn" onClick={() => setSheetOpen(true)}>Parts &amp; verses ↑</button>
        </section>

        <aside className={`st-panel${sheetOpen ? ' open' : ''}`} ref={panelRef}>
          <div className="st-sheet-bar" onPointerDown={onGripDown} onPointerMove={onGripMove} onPointerUp={onGripUp} onPointerCancel={onGripUp}>
            <span className="st-sheet-grip" /><button type="button" className="st-sheet-x" onClick={() => setSheetOpen(false)}>Model ×</button>
          </div>
          <Card model={model} id={sel} mode={mode} onClose={() => select(null)} onPick={select} />
        </aside>
      </div>
    </div>
  );
}
